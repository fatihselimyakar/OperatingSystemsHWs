/****************************************************/
/* Author     : Fatih Selim Yakar                   */
/* ID         : 161044054                           */
/* Title      : Operating Systems Midterm Part 3    */
/* Instructor : Yusuf Sinan Akgül                   */
/****************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <math.h>
#include <time.h>

#define MB 1048576
#define KB 1024
#define INODE_ENTRY_SIZE 210
#define DIRECTORY_ENTRY_SIZE 110
#define ROOTDIR_ENTRY_SIZE 66

int block_size;
int data_block_starts;
int nof_inodes;

/* Helper functions */
int get_inode_or_dir_num(FILE *fp,char *path,int is_file,int loop_reduce);
int search_string_in_file(FILE *fp,int lower_bound,int upper_bound,char* str);
int number_of_char_in_string(char ch,char* str);
void get_value_of_string(FILE *fp,char* search_string,char* output);
void get_value_of_string_range(FILE *fp,char* search_string,int lower_bound,int upper_bound,char* output);
int change_the_value_of_string(FILE *fp,char* search_string,int change_value);
void change_the_name_of_string(FILE *fp,char* main_string,char* search_string,char* name,int range);
void add_rootdir(FILE *fp,int is_file,char* name);

/* Main functions */
void mkdir(FILE *fp,char path[]);
void rm_dir(FILE *fp,char* path);
void write_disk(FILE *fp,char* path,char* filename);
void read_disk(FILE *fp,char* path,char* filename);
void list(FILE *fp,char* path);
void del(FILE *fp,char* path);
void dumpe2fs(FILE *fp);
int main(int argc,char *argv[]);

/* Gets the inode number or directory number in given path */
int get_inode_or_dir_num(FILE *fp,char *path,int is_file,int loop_reduce){
    /* Path dept is 20 */
    char tokenize[100],search_string[100],tokened[20][20],*p;
    int i,slash,offset;
    strcpy(tokenize,path);
    /* Controls root directory */
    if(strlen(path)==1 && path[0]=='/'){
        return 0;
    }
    p=strtok(tokenize,"/");
    i=0;
    while(p!=NULL){
        /* The last seperated string is value of the found string */
        strcpy(tokened[i],p); 
        p=strtok(NULL,"/");
        ++i;
    }
    /* if given path is root directory path */
    if((slash=number_of_char_in_string('/',path)+loop_reduce)==1){
        char name[100];
        if(loop_reduce==0)
            strcpy(name,path);
        else{
            /* Takes the first directory name */
            strcpy(name,path);
            strtok(name,"/");
        }
        /* if given root path is file */
        if(is_file){
            for(i=0;i<block_size/ROOTDIR_ENTRY_SIZE;++i){
                char comp[40];
                sprintf(search_string,"f_name%d",i);
                get_value_of_string(fp,search_string,comp);
                if(strcmp(comp,name+1)==0){
                    int j;
                    for(j=0;j<nof_inodes;++j){
                        char comp2[40];
                        sprintf(search_string,"inode%d",j);
                        offset=search_string_in_file(fp,0,MB,search_string);
                        get_value_of_string_range(fp,"filename",offset,MB,comp2);
                        if(strcmp(comp2,name+1)==0){
                            return j;
                        }
                    }
                }
            }
        } 
        /* if given root path is directory */
        else{
            for(i=0;i<block_size/ROOTDIR_ENTRY_SIZE;++i){
                char comp[40];
                sprintf(search_string,"d_name%d",i);
                get_value_of_string(fp,search_string,comp);
                if(strcmp(comp,name+1)==0){
                    int j;
                    for(j=0;j<(((MB/block_size)/20)*KB)/DIRECTORY_ENTRY_SIZE;++j){
                        char comp2[40];
                        sprintf(search_string,"directory%d",j);
                        offset=search_string_in_file(fp,0,MB,search_string);
                        get_value_of_string_range(fp,"dir_name",offset,MB,comp2);
                        if(strcmp(comp2,name+1)==0){
                            return j;
                        }
                    }
                }
            }
        }
    }
    /* given path is normal path */
    else{
        int ret_num;
        char p1[20],p2[20],f1[40],f2[40],f3[40],d1[40],d2[40];
        i=0;
        while(i<slash-1){
            /* The last seperated string is value of the found string */
            strcpy(p1,tokened[i]);
            strcpy(p2,tokened[i+1]);
            /* Directory link controls */
            if((is_file==1 && i<slash-2) || is_file==0){
                int main_offset;
                sprintf(search_string,"dir_name:[%s",p1);
                if((main_offset=search_string_in_file(fp,0,MB,search_string))!=-1){
                    int flag1=-1,flag2=-1;
                    get_value_of_string_range(fp,"d1",main_offset,MB,d1);
                    if(strcmp(d1,"d1")!=0){
                        sprintf(search_string,"directory%d",ret_num=atoi(d1));
                        offset=search_string_in_file(fp,0,MB,search_string);
                        get_value_of_string_range(fp,"dir_name",offset,MB,d1);
                        if(strcmp(d1,p2)!=0){
                            flag1=0;
                        }
                        else if(i==slash-2 && is_file==0){
                            return ret_num;
                        }
                    }
                    get_value_of_string_range(fp,"d2",main_offset,MB,d2);
                    if(strcmp(d2,"d2")!=0){
                        sprintf(search_string,"directory%d",ret_num=atoi(d2));
                        offset=search_string_in_file(fp,0,MB,search_string);
                        get_value_of_string_range(fp,"dir_name",offset,MB,d2);
                        if(strcmp(d2,p2)!=0){
                            flag2=0;
                        }
                        else if(i==slash-2 && is_file==0){
                            return ret_num;
                        }

                    }
                    if(flag1==0 && flag2==0){
                        return -1;
                    }
                }           
            }
            /* File link controls */
            if(is_file==1 && i==slash-2){
                sprintf(search_string,"dir_name:[%s",p1);
                offset=search_string_in_file(fp,0,MB,search_string);
                get_value_of_string_range(fp,"f1",offset,MB,f1);
                get_value_of_string_range(fp,"f2",offset,MB,f2);
                get_value_of_string_range(fp,"f3",offset,MB,f3);
                
                if(strcmp(f1,"f1")==0){
                    return -1;
                }
                sprintf(search_string,"inode%d",ret_num=atoi(f1));
                offset=search_string_in_file(fp,0,MB,search_string);
                get_value_of_string_range(fp,"filename",offset,MB,f1);
                if(strcmp(f1,p2)==0){
                    return ret_num;
                }

                if(strcmp(f2,"f2")==0){
                    return -1;
                }
                sprintf(search_string,"inode%d",ret_num=atoi(f2));
                offset=search_string_in_file(fp,0,MB,search_string);
                get_value_of_string_range(fp,"filename",offset,MB,f2);
                if(strcmp(f2,p2)==0){
                    return ret_num;
                }

                if(strcmp(f3,"f3")==0){
                    return -1;
                }
                sprintf(search_string,"inode%d",ret_num=atoi(f3));
                offset=search_string_in_file(fp,0,MB,search_string);
                get_value_of_string_range(fp,"filename",offset,MB,f3);
                if(strcmp(f3,p2)==0){
                    return ret_num;
                }
            }
            ++i;
        }
    }
    return -1;
}

/* It searches the string given as a parameter in the byte range given in the file system. Returns -1 if not found. */
int search_string_in_file(FILE *fp,int lower_bound,int upper_bound,char* str) {
	char temp[100*KB];
    fseek(fp,lower_bound,SEEK_SET);
	while((fgets(temp, 100*KB, fp) != NULL) && (ftell(fp)<=upper_bound)) {
		if((strstr(temp, str)) != NULL) {
            return ftell(fp)-(strlen(temp));
		}
	}
	return -1;

}

/* Returns the number of characters given as parameters inside the string given as a parameter. */
int number_of_char_in_string(char ch,char* str){
    int i;
    int ret_val=0;
    for(i=0;i<(int)strlen(str);++i){
        if(str[i]==ch)
            ++ret_val;
    }
    return ret_val;
}

/* Returns the value of the string with a value in file as a string. */
void get_value_of_string(FILE *fp,char* search_string,char* output){
    int start_directory=search_string_in_file(fp,0,MB,search_string);
    const char s[6]=":[] \n";
    char*p;
    size_t len;
    char* line=NULL;
    /* Sets the cursor to found the string's byte */
    fseek(fp,start_directory,SEEK_SET);

    /* Gets the found string's line */
    getline(&line,&len,fp);

    /* Seperates the line two to value and found string */
    p=strtok(line,s);
    while(p!=NULL){
        /* The last seperated string is value of the found string */
        strcpy(output,p); 
        p=strtok(NULL,s);
    }
}

/* Returns the value of the string with a value in file as a string between lower bound to upper bound bytes. */
void get_value_of_string_range(FILE *fp,char* search_string,int lower_bound,int upper_bound,char* output){
    int start_directory=search_string_in_file(fp,lower_bound,upper_bound,search_string);
    const char s[6]=":[] \n";
    char*p;
    size_t len;
    char* line=NULL;
    /* Sets the cursor to found the string's byte */
    fseek(fp,start_directory,SEEK_SET);

    /* Gets the found string's line */
    getline(&line,&len,fp);

    /* Seperates the line two to value and found string */
    p=strtok(line,s);
    while(p!=NULL){
        /* The last seperated string is value of the found string */
        strcpy(output,p); 
        p=strtok(NULL,s);
    }
}

/* Increases or decreases the value of the given string by the change_value given as a parameter. */
int change_the_value_of_string(FILE *fp,char* search_string,int change_value){
    char value[40];
    int int_value;
    get_value_of_string(fp,search_string,value);
    int_value=atoi(value);
    fseek(fp,-(floor(log10(int_value+1)+2)),SEEK_CUR);
    fprintf(fp,"%d",int_value+change_value);

    return int_value;
}

/* Changes the name of the string to given parameter name in given range */
void change_the_name_of_string(FILE *fp,char* main_string,char* search_string,char* name,int range){
    size_t offset;
    size_t name_starts;
    /* Goes the main string's offset */
    if(search_string_in_file(fp,0,MB,main_string)==-1){
        fprintf(stderr,"Error in change_the_name_of_string\n");
        exit(EXIT_FAILURE);
    }
    offset=ftell(fp);
    /* find offset of string that needs to be changed and overwrite with fprintf */
    name_starts=search_string_in_file(fp,offset,offset+range,search_string);
    fseek(fp,name_starts,SEEK_SET);
    fprintf(fp,"%s:[%s",search_string,name);
}

/* Adds new file or directory in file system's rootdir section */
void add_rootdir(FILE *fp,int is_file,char* name){
    int value;
    char search_string[100];
    sprintf(search_string,"/%s",name);
    if(get_inode_or_dir_num(fp,name,is_file,0)!=-1){
        fprintf(stderr,"There is already %s named file in Rootdir!\n",name);
        exit(EXIT_FAILURE);
    }
    /* adds the given name to first empty place */
    if(is_file){
        char val[40];
        get_value_of_string(fp,"root_files",val);
        /* finds first empty space */
        value=atoi(val);
        /* Changes the name */
        sprintf(search_string,"f_name%d",value);
        change_the_name_of_string(fp,"rootdir",search_string,name,block_size);
        /* Increases the first free root file address */
        change_the_value_of_string(fp,"root_files",1);
    }
    else{
        char val[40];
        get_value_of_string(fp,"root_directories",val);
        /* finds first empty space */
        value=atoi(val);
        /* Changes the name */
        sprintf(search_string,"d_name%d",value);
        change_the_name_of_string(fp,"rootdir",search_string,name,block_size);
        /* Increases the first free root directory address */
        change_the_value_of_string(fp,"root_directories",1);
    }
}

/* Creates new directory in the file system */
void mkdir(FILE *fp,char path[]){
    char search_string[100],name[20],parent_name[20],tokenize[50],*p;
    int start_directory;
    int slash=number_of_char_in_string('/',path);
    int int_directory_number=change_the_value_of_string(fp,"first_free_directory",1);

    /* Existence check */
    if(get_inode_or_dir_num(fp,path,0,0)!=-1){
        fprintf(stderr,"The parameter directory already exist!\n");
        change_the_value_of_string(fp,"first_free_directory",-1);
        exit(EXIT_FAILURE);
    }
    
    strcpy(tokenize,path);
    /* if the path is like /.../... */
    if(slash>1){
        int is_dir1_full=0,i=1,parent_dir_num;
        /* seperates the given path */
        p=strtok(tokenize,"/ \n");
        while(p!=NULL){
            if(i==slash-1){
                strcpy(parent_name,p);
            }
            else if(i==slash){
                strcpy(name,p);
            }
            p=strtok(NULL,"/ \n");
            ++i;
        }

        /* Checks for parent directory's existence */
        if((parent_dir_num=get_inode_or_dir_num(fp,path,0,-1))==-1){
            fprintf(stderr,"There is not parent \"%s\" named directory\n",parent_name);
            change_the_value_of_string(fp,"first_free_directory",-1);
            exit(EXIT_FAILURE);
        }

        /* Checks for main directory's existence */
        if(get_inode_or_dir_num(fp,path,0,0)!=-1){
            fprintf(stderr,"There is already exist \"%s\" named directory\n",name);
            change_the_value_of_string(fp,"first_free_directory",-1);
            exit(EXIT_FAILURE);
        }
        sprintf(search_string,"directory%d\n",parent_dir_num);
        start_directory=search_string_in_file(fp,0,MB,search_string);

        /* if parent directory's d1 is empty then saves d1 */
        is_dir1_full=search_string_in_file(fp,start_directory,start_directory+DIRECTORY_ENTRY_SIZE,"d1:[       ]");
        if(is_dir1_full!=-1){
            fseek(fp,is_dir1_full,SEEK_SET);
            fprintf(fp,"d1:[%d",int_directory_number);
        }
        /* if parent directory's d2 is empty then saves d2 */
        else if((is_dir1_full=search_string_in_file(fp,start_directory,start_directory+DIRECTORY_ENTRY_SIZE,"d2:[       ]"))!=-1){
            fseek(fp,is_dir1_full,SEEK_SET);
            fprintf(fp,"d2:[%d",int_directory_number);
        }
        /* If d2 is busy too then error occurs */
        else{
            fprintf(stderr,"There are only 2 directory in a directory!!\n");
            change_the_value_of_string(fp,"first_free_directory",-1);
            exit(EXIT_FAILURE);
        }

    }
    /* the path is like /... */
    else{
        if(path[0]=='/')
            strcpy(name,path+1);
        else
            strcpy(name,path);
        
        change_the_value_of_string(fp,"first_free_directory",-1);
        add_rootdir(fp,0,name);
        change_the_value_of_string(fp,"first_free_directory",1);
        
    }
    /* Decreases the global free_directories part in free space management */
    change_the_value_of_string(fp,"free_directories",-1); 

    /* Adds the name in the directory block */
    sprintf(search_string,"directory%d",int_directory_number);
    start_directory=search_string_in_file(fp,0,MB,search_string);

    fprintf(fp,"dir_name:[%s",name);

}

/* Remove directory in the file system */ 
void rm_dir(FILE *fp,char* path){
    int slash;
    char search_string[100],name[20];
    char f1[40],f2[40],f3[40],d1[40],d2[40],filename[40];
    size_t offset,root_offset;
    /* if the path is rootdir (/...) path then immediately removes */
    if((slash=number_of_char_in_string('/',path))==1){
        search_string_in_file(fp,0,MB,"rootdir");
        root_offset=8+search_string_in_file(fp,ftell(fp),ftell(fp)+block_size,path+1);
        strcpy(name,path+1);
    }
    /* if path is like /.../... */
    else{
        char *p,tokenize[50];
        int i=1;
        strcpy(tokenize,path);
        p=strtok(tokenize,"/");
       
        while(p!=NULL){
            if(i==slash){
                strcpy(name,p);
            }
            p=strtok(NULL,"/");
            ++i;
        }
    }
    
    /* Finds the directory and removes */
    if(get_inode_or_dir_num(fp,path,0,0)==-1){
        fprintf(stderr,"The path does not exist\n");
        exit(EXIT_FAILURE);
    }
    sprintf(search_string,"dir_name:[%s",name);
    offset=search_string_in_file(fp,0,MB,search_string);

    /* Also removes directories and files under the main directory */
    get_value_of_string_range(fp,"f1",offset,MB,f1);
    if(strcmp(f1,"f1")!=0){
        sprintf(search_string,"inode%d",atoi(f1));
        get_value_of_string_range(fp,"filename",search_string_in_file(fp,0,MB,search_string),MB,filename);
        sprintf(search_string,"%s/%s",path,filename);
        del(fp,search_string);
    }
    get_value_of_string_range(fp,"f2",offset,MB,f2);
    if(strcmp("f2",f2)!=0){
        sprintf(search_string,"inode%d",atoi(f2));
        get_value_of_string_range(fp,"filename",search_string_in_file(fp,0,MB,search_string),MB,filename);
        sprintf(search_string,"%s/%s",path,filename);
        del(fp,search_string);
    }
    get_value_of_string_range(fp,"f3",offset,MB,f3);
    if(strcmp(f3,"f3")!=0){
        sprintf(search_string,"inode%d",atoi(f3));
        get_value_of_string_range(fp,"filename",search_string_in_file(fp,0,MB,search_string),MB,filename);
        sprintf(search_string,"%s/%s",path,filename);
        del(fp,search_string);
    }
    get_value_of_string_range(fp,"d1",offset,MB,d1);
    if(strcmp(d1,"d1")!=0){
        sprintf(search_string,"directory%d",atoi(d1));
        get_value_of_string_range(fp,"dir_name",search_string_in_file(fp,0,MB,search_string),MB,filename);
        if(strcmp(filename,"dir_name")!=0){
            sprintf(search_string,"%s/%s",path,filename);
            rm_dir(fp,search_string);
        }
    }
    get_value_of_string_range(fp,"d2",offset,MB,d2);
    if(strcmp(d2,"d2")!=0){
        sprintf(search_string,"directory%d",atoi(d2));
        get_value_of_string_range(fp,"dir_name",search_string_in_file(fp,0,MB,search_string),MB,filename);
        if(strcmp(filename,"dir_name")!=0){
            sprintf(search_string,"%s/%s",path,filename);
            rm_dir(fp,search_string);
        }
    }

    /* Deletes the directory's name */
    fseek(fp,offset,SEEK_SET);
    fprintf(fp,"dir_name:[                    ]");

    if(slash==1){
        fseek(fp,root_offset,SEEK_SET);
        fprintf(fp,"[                    ]");
    }

    change_the_value_of_string(fp,"free_directories",+1);

}

/* Gets the file in the normal os and copies the individual file system */
void write_disk(FILE *fp,char* path,char* filename){
    char inode[50],name[20],parent_name[20],time_string[20],file_size_str[7],ch,val[40];
    int file_size,inode_number,offset,block=0,slash;
    time_t current_time;
    struct tm tm;
    FILE*fp2;

    /* Existence check */
    if(get_inode_or_dir_num(fp,path,1,0)!=-1){
        fprintf(stderr,"The parameter file already exist\n");
        exit(EXIT_FAILURE);
    }

    get_value_of_string(fp,"first_free_inode",val);
    inode_number=atoi(val);
    fp2=fopen(filename,"r");
    fseek(fp2,0,SEEK_END);
    file_size=ftell(fp2);

    /* Directory placement */
    /* If path is like /... */
    if((slash=number_of_char_in_string('/',path))==1){
        add_rootdir(fp,1,path+1);
        strcpy(name,path+1);
    }
    /* If path is like /.../... */
    else{
        char *p,tokenize[50],search_string[100];
        int i=1,dir_num;
        strcpy(tokenize,path);
        p=strtok(tokenize,"/ \n");
        while(p!=NULL){
            if(i==slash){
                strcpy(name,p);
            }
            if(i==slash-1){
                strcpy(parent_name,p);
            }
            p=strtok(NULL,"/ \n");
            ++i;
        }
        
        if((dir_num=get_inode_or_dir_num(fp,path,0,-1))==-1){
            fprintf(stderr,"There is not parent directory\n");
            exit(EXIT_FAILURE);
        }
        sprintf(search_string,"directory%d",dir_num);
        offset=search_string_in_file(fp,0,MB,search_string)+strlen(search_string);

        fseek(fp,offset,SEEK_SET);
        if(search_string_in_file(fp,offset,offset+DIRECTORY_ENTRY_SIZE,"f1:[       ]")!=-1){
            char val[40];
            get_value_of_string(fp,"first_free_inode",val);
            change_the_name_of_string(fp,search_string,"f1",val,DIRECTORY_ENTRY_SIZE);
        }
        else if(search_string_in_file(fp,offset,offset+DIRECTORY_ENTRY_SIZE,"f2:[       ]")!=-1){
            char val[40];
            get_value_of_string(fp,"first_free_inode",val);
            change_the_name_of_string(fp,search_string,"f2",val,DIRECTORY_ENTRY_SIZE);
        }
        else if(search_string_in_file(fp,offset,offset+DIRECTORY_ENTRY_SIZE,"f3:[       ]")!=-1){
            char val[40];
            get_value_of_string(fp,"first_free_inode",val);
            change_the_name_of_string(fp,search_string,"f3",val,DIRECTORY_ENTRY_SIZE);
        }
        else{
            fprintf(stderr,"There are only 3 file in a directory!!\n");
            exit(EXIT_FAILURE);
        }
        
    }

    /* Inode placement and updating global variables */
    sprintf(inode,"inode%d",inode_number);
    change_the_name_of_string(fp,inode,"filename",name,INODE_ENTRY_SIZE);
    change_the_value_of_string(fp,"first_free_inode",1);
    if(file_size<block_size){
        char val[40];
        get_value_of_string(fp,"first_free_data_block",val);
        change_the_name_of_string(fp,inode,"data1",val,INODE_ENTRY_SIZE);
        block=change_the_value_of_string(fp,"first_free_data_block",1);
        change_the_value_of_string(fp,"free_blocks",-1);
    }
    else if(file_size>block_size && file_size<2*block_size){
        char val[40],val2[40];
        get_value_of_string(fp,"first_free_data_block",val);
        change_the_name_of_string(fp,inode,"data1",val,INODE_ENTRY_SIZE);
        block=change_the_value_of_string(fp,"first_free_data_block",1);
        get_value_of_string(fp,"first_free_data_block",val2);
        change_the_name_of_string(fp,inode,"data2",val2,INODE_ENTRY_SIZE);
        change_the_value_of_string(fp,"first_free_data_block",1);
        change_the_value_of_string(fp,"free_blocks",-2);
    }
    else if(file_size>2*block_size && file_size<3*block_size){
        char val[40],val2[40],val3[40];
        get_value_of_string(fp,"first_free_data_block",val);
        change_the_name_of_string(fp,inode,"data1",val,INODE_ENTRY_SIZE);
        block=change_the_value_of_string(fp,"first_free_data_block",1);
        get_value_of_string(fp,"first_free_data_block",val2);
        change_the_name_of_string(fp,inode,"data2",val2,INODE_ENTRY_SIZE);
        change_the_value_of_string(fp,"first_free_data_block",1);
        get_value_of_string(fp,"first_free_data_block",val3);
        change_the_name_of_string(fp,inode,"data3",val3,INODE_ENTRY_SIZE);
        change_the_value_of_string(fp,"first_free_data_block",1);
        change_the_value_of_string(fp,"free_blocks",-3);
    }
    else{
        fprintf(stderr,"File size is too much your maximum file size is: %d bytes!!\n",3*block_size);
        exit(EXIT_FAILURE);
    }
    change_the_value_of_string(fp,"free_inodes",-1);
    
    /* size adding */
    sprintf(file_size_str,"%d",file_size);
    change_the_name_of_string(fp,inode,"size",file_size_str,INODE_ENTRY_SIZE);

    /* date adding */
    current_time=time(NULL);
    tm=*localtime(&current_time);
    sprintf(time_string,"%02d/%02d/%04d-%02d.%02d.%02d",tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900,tm.tm_hour, tm.tm_min, tm.tm_sec);
    change_the_name_of_string(fp,inode,"date",time_string,INODE_ENTRY_SIZE);

    /* copying the real file to disk */
    fseek(fp,data_block_starts+((block)*block_size),SEEK_SET);
    fseek(fp2,0,SEEK_SET);
    while( ( ch = fgetc(fp2) ) != EOF ){
        fprintf(fp,"%c",ch);
    }
    
    fclose(fp2);
}

/* Copies the individual system's file to real file */
void read_disk(FILE *fp,char* path,char* filename){
    char name[20],parent_name[20],search_string[100],ch;
    int offset,block=0,size=0,slash,file_no,dir_no,i;
    FILE*fp2=fopen(filename,"w");

    /* Existence check */
    if(get_inode_or_dir_num(fp,path,1,0)==-1){
        fprintf(stderr,"This path does not exist!\n");
        exit(EXIT_FAILURE);
    }
    
    /* if the given path is like /... */
    if((slash=number_of_char_in_string('/',path))==1){
        strcpy(name,path+1);
        if((file_no=get_inode_or_dir_num(fp,path,1,0))==-1){
            fprintf(stderr,"There is not %s named file for reading!\n",name);
            exit(EXIT_FAILURE);
        }
        sprintf(search_string,"inode%d",file_no);
        /* Gets the wanted file's block and size */
        if((offset=search_string_in_file(fp,0,MB,search_string))!=-1){
            char val[40],val2[40];
            get_value_of_string_range(fp,"data1",offset,MB,val);
            block=atoi(val);
            get_value_of_string_range(fp,"size",offset,MB,val2);
            size=atoi(val2);
        }
    }
    /* if the given path is like /.../... */
    else{
        char tokenize[50],*p,f1[40],f2[40],f3[40];
        int inode_block=0,inode_block2=0,inode_block3=0,i=1;
        strcpy(tokenize,path);
        p=strtok(tokenize,"/ \n");
        /* Gets the name and parent name of file */
        while(p!=NULL){
            if(i==slash){
                strcpy(name,p);
            }
            if(i==slash-1){
                strcpy(parent_name,p);
            }
            p=strtok(NULL,"/ \n");
            ++i;
        }

        /* Gets the wanted file's block and size */
        if((dir_no=get_inode_or_dir_num(fp,path,0,-1))==-1){
            fprintf(stderr,"There is not %s named parent directory for reading!\n",parent_name);
            exit(EXIT_FAILURE);
        }
        sprintf(search_string,"directory%d",dir_no);
        offset=search_string_in_file(fp,0,MB,search_string);
        get_value_of_string_range(fp,"f1",offset,MB,f1);
        get_value_of_string_range(fp,"f2",offset,MB,f2);
        get_value_of_string_range(fp,"f3",offset,MB,f3);
        
        if(strcmp(f1,"f1")!=0){
            char val[40],val2[40],val3[40];
            inode_block=atoi(f1);
            sprintf(search_string,"inode%d",inode_block);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"filename",offset,MB,val);
            if(strcmp(val,name)==0){    
                get_value_of_string_range(fp,"data1",offset,MB,val2);
                block=atoi(val2);
                get_value_of_string_range(fp,"size",offset,MB,val3);
                size=atoi(val3);
            }
            
        }
        if(strcmp(f2,"f2")!=0){
            char val[40],val2[40],val3[40];
            inode_block2=atoi(f2);
            sprintf(search_string,"inode%d",inode_block2);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"filename",offset,MB,val);
            if(strcmp(val,name)==0){
                get_value_of_string_range(fp,"data1",offset,MB,val2);
                block=atoi(val2);
                get_value_of_string_range(fp,"size",offset,MB,val3);
                size=atoi(val3);
            }
           
        }
        if(strcmp(f3,"f3")!=0){
            char val[40],val2[40],val3[40];
            inode_block3=atoi(f3);
            sprintf(search_string,"inode%d",inode_block3);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"filename",offset,MB,val);
            if(strcmp(val,name)==0){
                get_value_of_string_range(fp,"data1",offset,MB,val2);
                block=atoi(val2);
                get_value_of_string_range(fp,"size",offset,MB,val3);
                size=atoi(val3);
            }
        }   
        if(strcmp(f2,"f2")==0 && strcmp(f1,"f1")==0 && strcmp(f3,"f3")==0){
            fprintf(stderr,"The directory is empty!\n");
            exit(EXIT_FAILURE);
        }
        
    }
    /* Writes the individual file system's file to real file according to found size and block */
    fseek(fp,data_block_starts+((block)*block_size),SEEK_SET);
    i=0;
    while(i<size){
        ch = fgetc(fp);
        fprintf(fp2,"%c",ch);
        ++i;
    }

    fclose(fp2);
}

/* lists the content of given path */
void list(FILE *fp,char* path){
    int slash;
    char search_directory[20],search_file[20],name[20];
    /* Controls the directory exist */
    if(get_inode_or_dir_num(fp,path,0,-1)==-1){
        fprintf(stderr,"The directory does not exist!\n");
        exit(EXIT_FAILURE);
    }
    /* if the directory is root directory (/...) */
    if((slash=number_of_char_in_string('/',path))==1){
        int i=0;
        /* prints all of the directory names */
        while(i<block_size/ROOTDIR_ENTRY_SIZE){
            char string1[40];
            sprintf(search_directory,"d_name%d",i);
            get_value_of_string(fp,search_directory,string1);
            if(strcmp(string1,search_directory)!=0){
                printf("[DIR] %s\n",string1);
            }
            ++i;
        }
        i=0;
        /* prints all of the file names */
        while(i<block_size/ROOTDIR_ENTRY_SIZE){
            char string2[40],search_filename[50],size[7],date[20];
            int offset=0;
            sprintf(search_file,"f_name%d",i);
            get_value_of_string(fp,search_file,string2);
            if(strcmp(string2,search_file)!=0){
                sprintf(search_filename,"filename:[%s",string2);
                offset=search_string_in_file(fp,0,MB,search_filename);
                get_value_of_string_range(fp,"size",offset,offset+INODE_ENTRY_SIZE,size);
                get_value_of_string_range(fp,"date",offset,offset+INODE_ENTRY_SIZE,date);
                printf("[FILE] %s SIZE:%s DATE:%s\n",string2,size,date);
            }
            ++i;
        }
        
        
    }
    /* if the directory is normal directory ( /.../... ) */
    else{
        char *p,f1[40],f2[40],f3[40],d1[40],d2[40];
        char tokenize[50],search_string[100];
        int offset,file1,file2,file3,directory1,directory2,i=1;
        strcpy(tokenize,path);
        p=strtok(tokenize,"/ \n");
        while(p!=NULL){
            if(i==slash-1){
                strcpy(name,p);
            }
            p=strtok(NULL,"/ \n");
            ++i;
        }
        /* Accesses the all of directory and files under the main directory and prints these */
        sprintf(search_string,"directory%d",get_inode_or_dir_num(fp,path,0,-1));
        offset=search_string_in_file(fp,0,MB,search_string);

        get_value_of_string_range(fp,"f1",offset,MB,f1);
        get_value_of_string_range(fp,"f2",offset,MB,f2);
        get_value_of_string_range(fp,"f3",offset,MB,f3);
        get_value_of_string_range(fp,"d1",offset,MB,d1);
        get_value_of_string_range(fp,"d2",offset,MB,d2);
        if(strcmp(f1,"f1")!=0){
            char filename[40],size[7],date[20];
            file1=atoi(f1);
            sprintf(search_string,"inode%d",file1);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"filename",offset,MB,filename);
            if(strcmp(filename,"filename")!=0){
                get_value_of_string_range(fp,"size",offset,offset+INODE_ENTRY_SIZE,size);
                get_value_of_string_range(fp,"date",offset,offset+INODE_ENTRY_SIZE,date);
                printf("[FILE] %s SIZE:%s DATE:%s\n",filename,size,date);
            }
        }
        if(strcmp(f2,"f2")!=0){
            char filename[40],size[7],date[20];;
            file2=atoi(f2);
            sprintf(search_string,"inode%d",file2);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"filename",offset,MB,filename);
            if(strcmp(filename,"filename")!=0){
                get_value_of_string_range(fp,"size",offset,offset+INODE_ENTRY_SIZE,size);
                get_value_of_string_range(fp,"date",offset,offset+INODE_ENTRY_SIZE,date);
                printf("[FILE] %s SIZE:%s DATE:%s\n",filename,size,date);
            }
        }
        if(strcmp(f3,"f3")!=0){
            char filename[40],size[7],date[20];;
            file3=atoi(f3);
            sprintf(search_string,"inode%d",file3);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"filename",offset,MB,filename);
            if(strcmp(filename,"filename")!=0){
                get_value_of_string_range(fp,"size",offset,offset+INODE_ENTRY_SIZE,size);
                get_value_of_string_range(fp,"date",offset,offset+INODE_ENTRY_SIZE,date);
                printf("[FILE] %s SIZE:%s DATE:%s\n",filename,size,date);
            }
        }
        if(strcmp(d1,"d1")!=0){
            char dir_name[40];
            directory1=atoi(d1);
            sprintf(search_string,"directory%d",directory1);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"dir_name",offset,MB,dir_name);
            if(strcmp(dir_name,"dir_name")!=0){
                printf("[DIR] %s\n",dir_name);
            }
        }
        if(strcmp(d2,"d2")!=0){
            char dir_name[40];
            directory2=atoi(d2);
            sprintf(search_string,"directory%d",directory2);
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"dir_name",offset,MB,dir_name);
            if(strcmp(dir_name,"dir_name")!=0){
                printf("[DIR] %s\n",dir_name);
            }
        }
    }
}

/* Deletes the given file in the file system */
void del(FILE *fp,char* path){ 
    int slash,offset,size,control;
    char search_string[100],name[20],size_string[40];
    /* Controls existence of the file and initialize the search_string */
    sprintf(search_string,"inode%d",control=get_inode_or_dir_num(fp,path,1,0));
    if(control==-1){
        fprintf(stderr,"The file does not exist!\n");
        exit(EXIT_FAILURE);
    }
    /* if the path is like /... */
    if((slash=number_of_char_in_string('/',path))==1){
        strcpy(name,path+1);
        /* deleting in rootdir */
        offset=search_string_in_file(fp,0,MB,"rootdir");
        offset=search_string_in_file(fp,offset,offset+block_size,name);
        fseek(fp,-22,SEEK_CUR);
        fprintf(fp,"                    ");
    }
    /* if the path is like /.../... */
    else{
        char tokenize[50],*p;
        int i=1;
        strcpy(tokenize,path);
        p=strtok(tokenize,"/ \n");
        while(p!=NULL){
            if(i==slash){
                strcpy(name,p);
            }
            p=strtok(NULL,"/ \n");
            ++i;
        }
    }
    /* Searches the inode and deletes in inode */
    offset=search_string_in_file(fp,0,MB,search_string);
    sprintf(search_string,"filename:[%s",name);
    offset=search_string_in_file(fp,offset,MB,search_string);
    get_value_of_string_range(fp,"size",offset,offset+INODE_ENTRY_SIZE,size_string);
    size=atoi(size_string);
    fseek(fp,offset,SEEK_SET);
    fprintf(fp,"filename:[                    ]");

    /* deleting in the blocks */
    change_the_value_of_string(fp,"free_inodes",1);
    if(size/block_size==0)
        change_the_value_of_string(fp,"free_blocks",1); 
    else if(size/block_size==1){
        change_the_value_of_string(fp,"free_blocks",2); 
    }
    else if(size/block_size==2){
        change_the_value_of_string(fp,"free_blocks",3); 
    }
    else{
        fprintf(stderr,"Error in delete file\n");
        exit(EXIT_FAILURE);
    }

}

/* lists the crucial information in the file system */
void dumpe2fs(FILE *fp){
    int i,offset;
    char search_string[100];
    char nof_blocks_str[40],nof_inodes_str[40],nof_directories[40],free_blocks[40],free_inodes[40],free_directories[40];
    get_value_of_string(fp,"nof_blocks",nof_blocks_str);
    get_value_of_string(fp,"nof_inodes",nof_inodes_str);
    get_value_of_string(fp,"nof_directories",nof_directories);
    get_value_of_string(fp,"free_blocks",free_blocks);
    get_value_of_string(fp,"free_inodes",free_inodes);
    get_value_of_string(fp,"free_directories",free_directories);

    printf("Block size:%d\n",block_size);
    printf("Number of blocks:%s\n",nof_blocks_str);
    printf("Number of inodes:%s\n",nof_inodes_str);
    printf("Number of directories:%s\n",nof_directories);
    printf("Number of free blocks:%s\n",free_blocks);
    printf("Number of free inodes:%s\n",free_inodes);
    printf("Number of free directories:%s\n",free_directories); 

    /* prints additional informations */ 
    for(i=0;i<nof_inodes;++i){
        char filename[40];
        sprintf(search_string,"inode%d",i);  
        offset=search_string_in_file(fp,0,MB,search_string);
        get_value_of_string_range(fp,"filename",offset,offset+INODE_ENTRY_SIZE,filename);
        if(strcmp(filename,"filename")!=0){
            char data1[40],data2[40],data3[40];
            printf("inode:%d\n",i);
            printf("filename:%s\n",filename);

            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"data1",offset,offset+INODE_ENTRY_SIZE,data1);
            if(strcmp(data1,"data1")!=0){
                printf("data1:%s\n",data1);
            }
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"data2",offset,offset+INODE_ENTRY_SIZE,data2);
            if(strcmp(data2,"data2")!=0){
                printf("data2:%s\n",data2);
            }
            offset=search_string_in_file(fp,0,MB,search_string);
            get_value_of_string_range(fp,"data3",offset,offset+INODE_ENTRY_SIZE,data3);
            if(strcmp(data3,"data3")!=0){
                printf("data3:%s\n",data3);
            }
        }
    }
}

/* Runs File operations */
int main(int argc,char *argv[]){
    FILE *fp;
    int i;
    char file_name[20],command[10],parameter1[20],parameter2[20],b_size[40],d_block_starts[40],n_of_inodes[40];
    /* Seperates the given command line argument */
    for(i=1;i<argc;++i){
        switch(i){
            case 1:
                strcpy(file_name,argv[i]);
                break;
            case 2:
                strcpy(command,argv[i]);
                break;
            case 3:
                strcpy(parameter1,argv[i]);
                break;
            case 4:
                strcpy(parameter2,argv[i]);
                break;
        }
    }

    /* prints input parameters */
    printf("Input parameters:%s %s %s %s\n",file_name,command,parameter1,parameter2);

    /* Gets the crucial information in the file */
    fp = fopen(file_name, "r+");
    get_value_of_string(fp,"block_size",b_size);
    get_value_of_string(fp,"data_block_starts",d_block_starts);
    get_value_of_string(fp,"nof_inodes",n_of_inodes);
    block_size=atoi(b_size);
    data_block_starts=atoi(d_block_starts);
    nof_inodes=atoi(n_of_inodes);
    
    /* Runs command according to "command" parameter */
    if(strcmp(command,"list")==0){
        if(fp==NULL || argv[3]==NULL || strcmp(argv[3],"")==0){
            fprintf(stderr,"The parameter must be occupied.\n");
            exit(EXIT_FAILURE);
        }
        else{
            list(fp,parameter1);
        }
    }
    else if(strcmp(command,"mkdir")==0){
        if(fp==NULL || argv[3]==NULL || strcmp(argv[3],"")==0){
            fprintf(stderr,"The parameter must be occupied.\n");
            exit(EXIT_FAILURE);
        }
        else{
            mkdir(fp,parameter1);
        }
    }
    else if(strcmp(command,"rmdir")==0){
        if(fp==NULL || argv[3]==NULL || strcmp(argv[3],"")==0){
            fprintf(stderr,"The parameter must be occupied.\n");
            exit(EXIT_FAILURE);
        }
        else{
            rm_dir(fp,parameter1);
        }
    }
    else if(strcmp(command,"dumpe2fs")==0){
        if(fp==NULL){
            fprintf(stderr,"The parameter must be occupied.\n");
            exit(EXIT_FAILURE);
        }
        else{
            dumpe2fs(fp);
        }
    }
    else if(strcmp(command,"write")==0){
        if(fp==NULL || argv[3]==NULL || argv[4]==NULL || strcmp(argv[3],"")==0 || strcmp(argv[4],"")==0){
            fprintf(stderr,"The parameter must be occupied.\n");
            exit(EXIT_FAILURE);
        }
        else{
            write_disk(fp,parameter1,parameter2);
        }
    }
    else if(strcmp(command,"read")==0){
        if(fp==NULL || argv[3]==NULL || argv[4]==NULL || strcmp(argv[3],"")==0 || strcmp(argv[4],"")==0){
            fprintf(stderr,"The parameter must be occupied.\n");
            exit(EXIT_FAILURE);
        }
        else{
            read_disk(fp,parameter1,parameter2);
        }
    }
    else if(strcmp(command,"del")==0){
        if(fp==NULL || argv[3]==NULL || strcmp(argv[3],"")==0){
            fprintf(stderr,"The parameter must be occupied.\n");
            exit(EXIT_FAILURE);
        }
        else{
            del(fp,parameter1);
        }
    }
    else{
        fprintf(stderr,"The command is false!\n");
        exit(EXIT_FAILURE);
    }

    fclose(fp);

    return 0;
}
