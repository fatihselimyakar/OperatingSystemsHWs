/****************************************************/
/* Author     : Fatih Selim Yakar                   */
/* ID         : 161044054                           */
/* Title      : Operating Systems Midterm Part 2    */
/* Instructor : Yusuf Sinan Akgül                   */
/****************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define MB 1048576
#define KB 1024
#define INODE_ENTRY_SIZE 210
#define DIRECTORY_ENTRY_SIZE 110
#define ROOTDIR_ENTRY_SIZE 66

int block_size,nof_free_i_nodes,offset,nof_blocks,nof_inode_blocks,nof_inodes,nof_directory_blocks,magic,number;
char file_name[20],empty_string[21],empty_number[8];
FILE *fp;

/* First one block is superblock */
void superblock_placement(){
    fseek(fp,0,SEEK_SET);
    fprintf(fp,"superblock\n");
    fprintf(fp,"magic_number:%d\n",magic);
    fprintf(fp,"nof_blocks:%d\n",nof_blocks);
    fprintf(fp,"nof_directory_blocks:%d\n",nof_directory_blocks);
    fprintf(fp,"nof_inodes:%d\n",nof_inodes);
    fprintf(fp,"nof_directories:%d\n",(nof_directory_blocks*block_size*KB)/DIRECTORY_ENTRY_SIZE);
    fprintf(fp,"block_size:%d\n",KB*block_size);
    fprintf(fp,"inode_block_starts:%d\n",block_size*KB);
    fprintf(fp,"free_space_mgmt_block_starts:%d\n",block_size*KB*(nof_inode_blocks+1));
    fprintf(fp,"root_directory_block_starts:%d\n",block_size*KB*(nof_inode_blocks+2));
    fprintf(fp,"directory_block_starts:%d\n",block_size*KB*(nof_inode_blocks+3));
    fprintf(fp,"data_block_starts:%d\n",block_size*KB*(nof_inode_blocks+3+nof_directory_blocks));
}

/* second to [2+(10% of total blocks)]th are inode blocks */
void inode_block_placement(){
    int i;
    fseek(fp,block_size*KB,SEEK_SET);
    fprintf(fp,"\ninode_block\n");
    for(i=0;i<nof_inodes;++i){
        fprintf(fp,"inode%d\n",i);
        fprintf(fp,"filename:[%s]\n",empty_string);
        fprintf(fp,"data1:[%s]\n",empty_number);
        fprintf(fp,"data2:[%s]\n",empty_number);
        fprintf(fp,"data3:[%s]\n",empty_number);
        fprintf(fp,"single_indirect:[%s]\n",empty_number);
        fprintf(fp,"double_indirect:[%s]\n",empty_number);
        fprintf(fp,"triple_indirect:[%s]\n",empty_number);
        fprintf(fp,"size:[%s]\n",empty_number);
        fprintf(fp,"date:[%s]\n",empty_string);
    }
}
/* After the inode blocks, first one block is free space management block */
void free_space_block_placement(){
    fseek(fp,block_size*KB*(nof_inode_blocks+1),SEEK_SET);
    fprintf(fp,"\nfree_space_management\n");
    fprintf(fp,"free_inodes:%d\n",nof_inodes);
    fprintf(fp,"free_blocks:%d\n",nof_blocks-(nof_inode_blocks+nof_directory_blocks+3));
    fprintf(fp,"free_directories:%d\n",(nof_directory_blocks*block_size*KB)/DIRECTORY_ENTRY_SIZE);
    fprintf(fp,"first_free_inode:000000\n");
    fprintf(fp,"first_free_directory:000000\n");
    fprintf(fp,"first_free_data_block:000000\n");
    fprintf(fp,"root_files:000000\n");
    fprintf(fp,"root_directories:000000\n");
}

/* After the free space management block, first one block is rootdir block */
void rootdir_placement(){
    int i;
    /* Rootdir: (nof_inode_blocks+2)th block */
    fseek(fp,block_size*KB*(nof_inode_blocks+2),SEEK_SET);
    fprintf(fp,"\nrootdir\n");
    for(i=0;i<(block_size*KB)/ROOTDIR_ENTRY_SIZE;++i){
        fprintf(fp,"d_name%d:[%s]\n",i,empty_string);
        fprintf(fp,"f_name%d:[%s]\n",i,empty_string);
    }
}

void files_and_directories_placement(){
    int i;
    /* Files and directories: (nof_inode_blocks+3)th block */
    fseek(fp,block_size*KB*(nof_inode_blocks+3),SEEK_SET);
    fprintf(fp,"\nfiles_and_directories\n");
    for(i=0;i<(nof_directory_blocks*block_size*KB)/DIRECTORY_ENTRY_SIZE;++i){
        fprintf(fp,"directory%d\n",i);
        fprintf(fp,"dir_name:[%s]\n",empty_string);
        fprintf(fp,"f1:[%s]\n",empty_number);
        fprintf(fp,"f2:[%s]\n",empty_number);
        fprintf(fp,"f3:[%s]\n",empty_number);
        fprintf(fp,"d1:[%s]\n",empty_number);
        fprintf(fp,"d2:[%s]\n",empty_number);
    }
}

int main(int argc,char *argv[]){
    int i;
    for(i=1;i<argc;++i){
        switch(i){
            case 1:
                block_size=atoi(argv[i]);
                break;
            case 2:
                nof_free_i_nodes=atoi(argv[i]);
                break;
            case 3:
                strcpy(file_name,argv[i]);
                break;
        }
    }

    /* Empty string and number initialization */
    for(i=0;i<21;++i){
        empty_string[i]=' ';
        if(i==20)
            empty_string[i]='\0';
    }
    for(i=0;i<8;++i){
        empty_number[i]=' ';
        if(i==7)
            empty_number[i]='\0';
    }

    printf("Inputs : %d %d %s\n",block_size,nof_free_i_nodes,file_name);

    /* File opening and size extending the 1MB */
    offset = MB-1;
    fp = fopen(file_name, "w+");
    fseek(fp, offset , SEEK_SET);
    fprintf(fp,"%c",'\0');

    /* Superblock info's calculation */
    magic=0;
    nof_blocks=MB/(block_size*KB);      /* # of block calculation */
    nof_inode_blocks=nof_blocks/10;     /* Total of 10% is inode block */
    nof_directory_blocks=nof_blocks/20; /* Total of 5% is directory block */
    nof_inodes=nof_free_i_nodes;        /* # of inodes */

    /* if inodes are too much then exits with printing error */
    if(nof_free_i_nodes*INODE_ENTRY_SIZE>nof_inode_blocks*block_size*KB){
        fprintf(stderr,"Entered inode value is too much. This is the value you can enter the most:%d\n",(nof_inode_blocks*block_size*KB)/INODE_ENTRY_SIZE);
        exit(EXIT_FAILURE);
    }

    printf("Number of blocks : %d\nNumber of inode blocks : %d\nNumber of inodes : %d\n",nof_blocks,nof_inode_blocks,nof_inodes);

    superblock_placement();
    inode_block_placement();
    free_space_block_placement();
    rootdir_placement();
    files_and_directories_placement();

    fclose(fp);

    return 0;
}
